// Mini reto Luis Miguel Zozaya

import UIKit

var r = ["Bingo!!!","par!!!","impar!!!","Viva swift!!!"]

for num in 0...100{
    if num >= 30 && num <= 40{
        print("\(num)\t\(r[3])")
    }
    else if num % 5 == 0{
        print("\(num)\t\(r[0])")
    }
    else if num % 2 == 0{
        print("\(num)\t\(r[1])")
    }
    else{
        print("\(num)\t\(r[2])")
    }

}
