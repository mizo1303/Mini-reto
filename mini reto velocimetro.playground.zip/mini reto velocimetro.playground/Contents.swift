//: Playground - noun: a place where people can play

import UIKit

enum Velocidades: Int {
    
    case apagado = 0, velocidadBaja = 20, velocidadMedia = 50, velocidadAlta = 120
    
    init (velocidadInicial: Velocidades) {
        
        self = velocidadInicial
    }
}

class Auto {
    
    var velocidad: Velocidades
    
    init () {
        
        velocidad = Velocidades(velocidadInicial: Velocidades.apagado)
    }
    
    func cambioDeVelocidad () -> (actual: Int, velocidadEnCadena: String) {
        
        let actual = velocidad
        var velocidadEnCadena: String?
        
        switch velocidad {
            
        case Velocidades.apagado:
            velocidadEnCadena = "Apagado"
            velocidad = Velocidades.velocidadBaja
            
        case Velocidades.velocidadBaja:
            velocidadEnCadena = "Baja"
            velocidad = Velocidades.velocidadMedia
            
        case Velocidades.velocidadMedia:
            velocidadEnCadena = "Media"
            velocidad = Velocidades.velocidadAlta
            
        case Velocidades.velocidadAlta:
            velocidadEnCadena = "Alta"
            velocidad = Velocidades.velocidadMedia
        }
        
        return (actual.rawValue, velocidadEnCadena!)
    }
}

let auto = Auto()

for vel in 1...20 {
    
    let x = auto.cambioDeVelocidad()
    
    print("\(x.actual), \(x.velocidadEnCadena)")
}

